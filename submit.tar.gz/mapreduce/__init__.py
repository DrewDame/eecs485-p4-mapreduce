"""
Mapreduce python package.

Amy Chern <chernamy@umich.edu>
Nilay Muchhala <nilaym@umich.edu>
"""

from mapreduce.manager import Manager
from mapreduce.worker import Worker
